import React, {Component} from 'react';
import {Table} from 'react-bootstrap';

class ProductList extends Component {
  getProducts(){
    return [{
      //+Bonus class Product() -->newProduct(....)
      //+Bonus npm -> faker ->generate products()
      photo: "./images/pl.jpg",
      name: "aiFoon xxl",
      price:{
        amount:100,
        currency: "USD"
      },
      rating: 4.5,
      promo: true
      },
    ]
  }

render(){
    return(
      <div class="container mt-3" >
        <Table striped bordered hover>
  <thead>
    <tr>
      <th>Photo</th>
      <th>Name</th>
      <th>Price</th>
      <th>Rating</th>
    </tr>
  </thead>
  <tbody>
    {/* ciclu /for - cu froduse*/}
    <tr>
      <td>1</td>
      <td>Mark</td>
      <td>Otto</td>
      <td>@mdo</td>
    </tr>
    <tr>
      <td>2</td>
      <td>Jacob</td>
      <td>Thornton</td>
      <td>@fat</td>
    </tr>
    <tr>
      <td>3</td>
      <td colSpan="2">Larry the Bird</td>
      <td>@twitter</td>
    </tr>
  </tbody>
</Table>
</div>
    )
}
}
export default ProductList