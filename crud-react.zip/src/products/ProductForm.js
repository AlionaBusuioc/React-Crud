import React, {Component} from 'react';
import {Form, Button} from 'react-bootstrap';

class ProductForm extends Component {
    constructor(){
        super()
        this.state = {
            validated: false
        }
    }
    handleSubmit(event){
        event.preventDefault(); //nu permite browserului sa faca submit (refresh)
        alert();
    }
    render(){
        return(
            <div id="product-form">
                <Form onSubmit={e => this.handleSubmit(e)} className="container mt-5">
                    <Form.Group>
                        <Form.Control type="text" placeholder="product name" size="lg"/>  
                    </Form.Group>
                    <Form.Group>
                        <Form.Control type="text" placeholder="product name" size="lg"/>  
                    </Form.Group>
                    <Form.Group>
                        <Form.Control type="text" placeholder="product name" size="lg"/>  
                    </Form.Group>
                    <Form.Group>
                        <Form.Control type="text" placeholder="product name" size="lg"/>  
                    </Form.Group>
                    <Button type="submit">Save</Button>
                </Form>
            </div>
        )
    }
}
export default ProductForm;