import React from 'react';
import {BrowserRouter as Router,Link, Route} from 'react-router-dom'
import {Navbar,Button} from 'react-bootstrap'
// import logo from './logo.svg';
import './App.css';
import ProductForm from './products/ProductForm';
import ProductList from './products/ProductList';

function App() {
  return (
    <div className="App">
      <Router>
      <Route path="/product/add" component={ProductForm}/>
      <Route path="/products" component={ProductList}/>

        <Navbar className="container" fixed="bottom">
        <Link to="/products" className="mr-auto">
          <Button variant="secondary" size="lg" className="shadow">Products
          </Button>
        </Link>
        <Link to="/product/add" className="ml-auto">
          <Button variant="primary" size="lg" className="rounded-pill shadow">+
          </Button>
        </Link>
        </Navbar>
        {/* <Route path="/product/add" component={ProductForm}/> */}
      </Router>
    </div>
  );
}

export default App;
